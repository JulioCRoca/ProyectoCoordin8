#ifndef LauFunciones_H  // Directiva de inclusion multiple
#define LauFunciones_H
#include <string>
using namespace std;
void mostrarPaquete1();
void mostrarPaquete2();
void mostrarPaquete3();
bool confirmarPaquete(int opcion);



#endif // LauFunciones_H