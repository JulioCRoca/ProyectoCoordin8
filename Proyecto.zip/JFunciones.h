
// JFunciones.h
#ifndef JFunciones_H  // Directiva de inclusion multiple
#define JFunciones_H
#include<string>
using namespace std;
void dibujar();
bool verificarCI(string CI);
void cargando();
void ambiente(int festejo, int& opcion, int& opmusic);



#endif // FUNCIONES_H
