
#ifndef LoginJ_H  // Directiva de inclusion multiple
#define LoginJ_H
#include <string>
using namespace std;
void pintar(int i);
void loginJ(int &eleccion1,int &eleccion2);


#endif // Login_H